#ifndef __MAIN_H__
#define __MAIN_H__

#include "stm32f4xx.h"
#include "can1.h"
#include "delay.h"

#define abs(x) ((x)>0? (x):(-(x)))

#endif 
